<?php
	if(isset($do)){
		$page=$do;
	}else{
		$page="";
	}
	switch ($page) {
		case 'recep_add':
			include_once("module/reception/add_reception_stu.php");
			break;
		case 'recep_list':
			include_once("module/reception/see_reception_stu.php");
			break;
      default: echo "page not found";
      break;
    }
    ?>
