<?php
// session_destroy();
if(isset($_POST['token_no']))
{
  $success=1;
if( $_POST['name']=="")
{
  $_SESSION['ename']="Enter Your Name";
  $success=0;
}
if($_POST['f_name']=="")
{
  $_SESSION['fname']="Enter Your Father Name";
  $success=0;
}
if($_POST['m_name']=="")
{
  $_SESSION['mname']="Enter Your Mother Name";
  $success=0;
}
if(!isset($_POST['send_to']) || $_POST['send_to']=="")
{
  $_SESSION['class']="Enter Your Class";
  $success=0;
}
if(!isset($_POST['refer_to']) || $_POST['refer_to']=="")
{
  $_SESSION['batch']="Enter Your Batch";
  $success=0;
}
if($success)
{
  addUpdate(stu_profile,$_POST,$id);
  ?>
  <script>
  location.href=root_path+"index/reception/recep_add";
  </script>
<?php }
} ?>

<div class="col-lg-12" style="border:1px dotted #CCC;">
<form role="form" class="form-horizontal" enctype="multipart/form-data" method="post">
	<div class="col-lg-6">
            	<div class="form-group">
                	<label class="col-lg-4 control-label"></label>
                    <div class="col-lg-8">
                      <?php
                        $last_token_no=fetchOne("Select token_no from stu_profile order by id desc");
                        $last_token_no['token_no']++;
                      ?>
                    <input type="text" class="form-control" value="<?php echo $last_token_no['token_no']; ?>" id="roll" name="token_no" value="" pattern=".{3}" maxlength="4" onkeyup="this.value=this.value.replace(/[^0-9]/g,'');" style="text-transform:capitalize;">
                    </div>
                </div>
                <div class="form-group">
                	<label class="col-lg-4 control-label">Student Name</label>
                    <div class="col-lg-8">
                    <input type="text" class="form-control" id="s_name" name="name" value="" style="text-transform:capitalize;">
                    </div>
                    <?php if(isset($_SESSION['ename'])){echo $_SESSION['ename']; unset($_SESSION['ename']);} ?>
                </div>
                <div class="form-group">
                	<label class="col-lg-4 control-label">Father Name</label>
                    <div class="col-lg-8">
                    <input type="text" class="form-control" id="f_name" name="f_name" value="" style="text-transform:capitalize;">
                    </div>
                    <?php if(isset($_SESSION['fname'])){echo $_SESSION['fname']; unset($_SESSION['fname']);} ?>
                </div>
                <div class="form-group">
                	<label class="col-lg-4 control-label">Mother Name</label>
                    <div class="col-lg-8">
                    <input type="text" class="form-control" id="m_name" name="m_name" value="" style="text-transform:capitalize;">
                    </div>
                    <?php if(isset($_SESSION['mname'])){echo $_SESSION['mname']; unset($_SESSION['mname']);} ?>
                </div>
                <div class="form-group">
                  <label class="col-lg-4 control-label">Mobile No. (Student)</label>
                    <div class="col-lg-8">
                    <input type="text" class="form-control" id="s_mobile" name="s_mobile" value="" pattern=".{10}" maxlength="10" onkeyup="this.value=this.value.replace(/[^0-9]/g,'');" style="text-transform:capitalize;">
                    </div>
                      <?php if(isset($_SESSION['smobile'])){echo $_SESSION['smobile']; unset($_SESSION['smobile']);} ?>
                </div>
                <div class="form-group">
                  <label class="col-lg-4 control-label">Gender</label>
                    <div class="col-lg-8">
                    <select class="form-control" id="gender" name="gender">
                      <option></option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                    </div>
                      <?php if(isset($_SESSION['sgender'])){echo $_SESSION['sgender']; unset($_SESSION['sgender']);} ?>
                </div>
                <div class="form-group">
                  <label class="col-lg-4 control-label">Interested In :</label>
                    <div class="col-lg-8">
                    <select onchange="show(this.value)" class="form-control" id="batch" name="send_to">
                      <option></option>
                        <option>Counselling</option>
                        <option>Inquery</option>
                        <option>Admission</option>
                    </select>
                    </div>
                    <?php if(isset($_SESSION['sendto'])){echo $_SESSION['sendto']; unset($_SESSION['sendto']);} ?>
                </div>

                <div class="form-group">
                  <label class="col-lg-4 control-label">Refers To :</label>
                    <div class="col-lg-8">
                    <select class="form-control" disabled id="refer" name="refer_to">
                      <option value=""></option>

                    </select>
                    </div>
                    <?php if(isset($_SESSION['referto'])){echo $_SESSION['referto']; unset($_SESSION['referto']);} ?>
                </div>
                <div class="form-group">
                      <div class="col-lg-8 col-lg-offset-4">
                        <button type="submit"  id="submit" class="btn btn-danger btn-sm btn-block" style="font-family:'Century Gothic'; font-size:14px; font-weight:bold;">SUBMIT & GENERATE TOKEN</button>
                        </div>
                    </div>
              </div></form></div>
                <script type="text/javascript">
                  function show(option){
                    if(option=='Counselling' || option=='Inquery' ){
                      $('#refer').html("<option>Abc</option><option>PQR</option>");
                      $('#refer').removeAttr("disabled");
                    }else if(option=='Admission'){
                      $('#refer').html("<option>Accountant</option>");
                    }
                  }
                </script>
