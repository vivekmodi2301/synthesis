<?php
  if(isset($_GET['id'])){
      delete('stu_profile',$_GET['id']);
      ?>
          <script type="text/javascript">
              location.href=root_path+"index/reception/recep_list/";
          </script>
      <?php
  }
?><div class="col-lg-12 table-responsive" style="margin-left:10px; font-family:'Century Gothic';">

            <table class="table table-bordered table-hover">
          <tr class="active1 table_style" style="font-weight:600;">
                <td width="100">Sr. No.</td>
                <td width="300">Name</td>
                <td width="300">Father Name</td>
                <td width="300">Mother Name</td>
                <td width="300">Mobile No (Student)</td>
                <td width="300">Gender</td>
                <td width="300">Intersted In</td>
                <td width="300">Refer To</td>
                <td width="300">Token No.</td>
                <td width="200" colspan="2">Action</td>
            </tr>
            <?php
                $sno=1;
                $stu_recp_data=fetchAll("Select id, name,f_name,m_name,s_mobile,gender,send_to,refer_to,token_no from stu_profile");
                foreach ($stu_recp_data as $stu_recp_value) {
            ?>
                    <tr class="primary1 table_style2">
                        <td><?php echo $sno++; ?></td>
                        <td><?php echo $stu_recp_value['name'] ?></td>
                        <td><?php echo $stu_recp_value['f_name']; ?></td>
                        <td><?php echo $stu_recp_value['m_name'] ?></td>
                        <td><?php echo $stu_recp_value['s_mobile']; ?></td>
                        <td><?php echo $stu_recp_value['gender'] ?></td>
                        <td><?php echo $stu_recp_value['send_to']; ?></td>
                        <td><?php echo $stu_recp_value['refer_to'] ?></td>
                        <td><?php echo $stu_recp_value['token_no']; ?></td>
                        <td><a href="#" onclick="del(<?php echo $stu_recp_value['id'];?>)" title="Delete Class"><img src="<?php echo ROOT; ?>include/images/trash.png" height="20" width="20" /></a></td>
                    </tr>
                <?php }?>
        </table>

  </div>
  <script type="text/javascript">
      function del(did){
        if(confirm("Do you really want to delete")){
            location.href=root_path+"index/reception/recep_list/"+did;
        }
      }
  </script>
