<table class="table table-bordered">
	<tr>
		<th>Enter Roll no. or Token No.</th>
	</tr>
	<tr>
		<td><input type="text" id="roll" onkeyup="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" onchange="showdtl(this.value)"></td>
	</tr>
    
     <span><input type="hidden" value="0" id="total_chq"></span>
</table>

<div id="show">
</div>
<script type="text/javascript">
	function showdtl(roll){
		$.ajax({
			 url:root_path+"module/stu_library/dtl_stu_lib.php",
	        data:"roll="+roll,
	        type:"post",
	        success:function(e){
	            $('#show').html(e);
	        }
        });
	}
	
    //add cheque
    function add_more_cheque(){
        $('#total_chq').val(parseInt($('#total_chq').val())+1);
        var new_chq_no=$('#total_chq').val();
        $.ajax({
            url:root_path+"module/stu_library/addfile.php",
            data:"new_chq_no="+new_chq_no,
            type:"post",
            success:function(e){
                $('#new_chq').append(e);
            }
        });
    }
    //remove pdc
    function remove_pdc(){
        var last_chq_no=$('#total_chq').val();
        // alert(last_chq_no);
        if(last_chq_no>1){
            $('#new_'+last_chq_no).remove();
            $('#total_chq').val(last_chq_no-1);
        }
    }
</script>
